/**
 * Sistema de Cadastro de Alunos
 * 
 * Funcionalidades:
 * - Adicionar novos alunos
 * - Editar alunos existentes
 * - Remover alunos
 * - Buscar alunos por nome
 * - Persistência em localStorage
 */

// Variáveis globais
const alunos = JSON.parse(localStorage.getItem('alunos')) || [];
let editIndex = -1; // Índice para controle de edição

// Elementos DOM
const elementos = {
  form: document.getElementById('form-aluno'),
  tabela: document.getElementById('tabela-alunos').querySelector('tbody'),
  buscar: document.getElementById('buscar'),
  campos: {
    nome: document.getElementById('nome'),
    idade: document.getElementById('idade'),
    curso: document.getElementById('curso')
  }
};

// Funções principais
const metodos = {
  /**
   * Atualiza a tabela de exibição dos alunos
   * @param {string} filtro - Termo para filtrar alunos por nome
   */
  atualizarTabela(filtro = '') {
    elementos.tabela.innerHTML = '';
    
    alunos
      .filter(aluno => aluno.nome.toLowerCase().includes(filtro.toLowerCase()))
      .forEach((aluno, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${aluno.nome}</td>
          <td>${aluno.idade}</td>
          <td>${aluno.curso}</td>
          <td>
            <button class="action-btn edit-btn" onclick="metodos.editarAluno(${index})">
              Editar
            </button>
            <button class="action-btn remove-btn" onclick="metodos.removerAluno(${index})">
              Remover
            </button>
          </td>
        `;
        elementos.tabela.appendChild(tr);
      });
  },

  /**
   * Salva a lista de alunos no localStorage
   */
  salvarLocalStorage() {
    localStorage.setItem('alunos', JSON.stringify(alunos));
  },

  /**
   * Manipula o envio do formulário (criação/edição)
   * @param {Event} e - Evento de submit
   */
  handleSubmit(e) {
    e.preventDefault();
    
    const aluno = {
      nome: elementos.campos.nome.value.trim(),
      idade: elementos.campos.idade.value,
      curso: elementos.campos.curso.value.trim()
    };

    if (editIndex >= 0) {
      // Modo edição
      alunos[editIndex] = aluno;
      editIndex = -1;
    } else {
      // Modo criação
      alunos.push(aluno);
    }

    this.salvarLocalStorage();
    this.atualizarTabela();
    elementos.form.reset();
  },

  /**
   * Remove um aluno da lista
   * @param {number} index - Índice do aluno a ser removido
   */
  removerAluno(index) {
    if (confirm("Tem certeza que deseja remover este aluno?")) {
      alunos.splice(index, 1);
      this.salvarLocalStorage();
      this.atualizarTabela(elementos.buscar.value);
    }
  },

  /**
   * Preenche o formulário para edição
   * @param {number} index - Índice do aluno a ser editado
   */
  editarAluno(index) {
    const aluno = alunos[index];
    elementos.campos.nome.value = aluno.nome;
    elementos.campos.idade.value = aluno.idade;
    elementos.campos.curso.value = aluno.curso;
    editIndex = index;
  },

  /**
   * Filtra alunos conforme digitação no campo de busca
   */
  handleBusca() {
    this.atualizarTabela(elementos.buscar.value);
  }
};

// Event Listeners
elementos.form.addEventListener('submit', (e) => metodos.handleSubmit(e));
elementos.buscar.addEventListener('input', () => metodos.handleBusca());

// Inicialização
window.metodos = metodos; // Torna os métodos disponíveis globalmente (para os eventos inline)
metodos.atualizarTabela();